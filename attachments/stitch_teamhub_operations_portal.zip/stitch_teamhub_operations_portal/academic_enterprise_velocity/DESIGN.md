---
name: Academic Enterprise Velocity
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76767e'
  outline-variant: '#c6c6ce'
  surface-tint: '#545d7c'
  primary: '#06102b'
  on-primary: '#ffffff'
  primary-container: '#1c2541'
  on-primary-container: '#838cae'
  inverse-primary: '#bdc5e9'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#200c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#3e1e00'
  on-tertiary-container: '#d57401'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#bdc5e9'
  on-primary-fixed: '#111a36'
  on-primary-fixed-variant: '#3d4664'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system establishes a high-performance, developer-grade workspace tailored for college engineering teams, capstone candidates, faculty guides, and internship coordinators. Inspired by tools like Linear, GitHub Projects, and Vercel, it pairs modern enterprise software ergonomics with the collegiate authority and heritage of the institution's emblem. 

The aesthetic is characterized by:
- **Engineered Precision & Density:** High data density, compact table rows, crisp 1px borders, and zero ornamental clutter.
- **Academic Authority:** Anchored in rich collegiate midnight navy and burnished gold accents derived from the university crest, balanced against sterile, utilitarian slate surfaces.
- **Developer-Centric Velocity:** Keyboard-driven interaction patterns, monospaced metadata callouts, atomic status indicators, and low-latency visual feedback.

## Colors

The palette balances deep naval structure, vibrant programmatic interactions, institutional gold, and calibrated slate neutrals to deliver uncompromising legibility across complex dashboards, Gantt views, and pull-request trackers.

### Role Assignments

- **Primary (`#1C2541` / Deep Naval Slate):** Root navigation shells, primary button backgrounds, master headings, and high-emphasis focal strokes. Paired with `#0B132B` for deep contrast sidebars and header framing.
- **Secondary (`#4F46E5` / Electric Indigo):** Active states, focused inputs, interactive links, primary action triggers, and sprint progression bars. Complementary accent `#3B82F6` serves live telemetry and data-visualization vectors.
- **Tertiary (`#D97706` / Academic Crest Gold):** Institutional verification marks, milestone awards, capstone sponsorship tags, and grade reviews. Darkens to `#B45309` for accessible typography on light backgrounds.
- **Neutrals (`#F8FAFC` to `#0F172A`):** `#F8FAFC` provides the canvas surface; `#F1F5F9` and `#FFFFFF` form stacked table and card tiers; `#E2E8F0` serves as structural borders; `#334155` and `#0F172A` handle secondary and primary copy.

### Semantic Status Palette
- **Healthy / Approved:** Emerald (`#059669` background tint `#ECFDF5`, border `#A7F3D0`).
- **At Risk / Pending:** Amber (`#D97706` background tint `#FFFBEB`, border `#FDE68A`).
- **Blocked / Rejected:** Crimson (`#DC2626` background tint `#FEF2F2`, border `#FECACA`).
- **Submitted / Queued:** Indigo (`#4F46E5` background tint `#EEF2FF`, border `#C7D2FE`).

## Typography

The type system blends the geometric authority of **Plus Jakarta Sans** for structure and identity headers with the analytical clarity of **Inter** for data grids, telemetry logs, and body content. Monospaced identifiers (commit hashes, sprint keys, ticket IDs) leverage **JetBrains Mono**.

- **Display & Section Headers:** Set with tight tracking (`-0.02em` to `-0.025em`) to evoke the technical poise of modern developer tools.
- **Data & Tables:** Standardized on `body-md` (14px) and `body-sm` (12px) with tabular lining figures (`font-variant-numeric: tabular-nums`) enabled to guarantee alignment across numerical tables, task trackers, and sprint velocities.
- **Labels & Tags:** Uppercase or title-cased `label-sm` (11px) with slightly expanded tracking (`+0.02em`) for immediate readability inside compact badges and metadata rows.

## Layout & Spacing

The layout model emphasizes structured density and clean information hierarchy, matching the high productivity layouts of GitHub and Linear.

### Grid & Density Rhythm
- **Global Layout Structure:** A fixed-fluid hybrid. The global app shell utilizes a persistent collapsible navigation sidebar (240px wide on desktop, collapsed to 64px icon-rail or hidden on mobile/tablet drawer), flanking a full-bleed multi-pane content area maxing out at `1600px` for ultra-wide monitors.
- **Sub-layouts:** Dashboards and project boards rely on a flexible 12-column grid system with 16px (`1rem`) gutters on viewports under 1280px, expanding to 24px (`1.5rem`) on high-resolution displays.
- **Compact Padding Rules:** Component-level vertical padding is intentionally compressed (`space-xs` and `space-sm` for table rows and buttons) to maintain maximum visible workspace above the fold.
- **Breakpoints:**
  - **Mobile (<768px):** Single-column stacked layouts, hidden non-critical metadata, bottom action sheets replacing floating dialogs.
  - **Tablet (768px - 1024px):** 2-column adaptive panels, collapsible sidebars, horizontal scroll-containers for Kanban boards.
  - **Desktop (>1024px):** Multi-pane split views (e.g., project issue list on the left, issue detail pane on the right).

## Elevation & Depth

This design system rejects heavy blurs, dramatic drop shadows, and skeuomorphic gradients in favor of sharp planar discipline and low-contrast borders.

- **Surface Tiers:**
  - **Base Canvas:** `#F8FAFC` (Root screen background).
  - **Surface Level 1:** `#FFFFFF` (Data tables, main card backgrounds, sidebar containers).
  - **Surface Level 2:** `#F1F5F9` (Nested panels, table header tracks, subtle hover backings).
  - **Surface Level 3 / Accent Inset:** `#E2E8F0` (Dividers, active drag placeholders, keyboard shortcut badges).
- **Structural Outlines:** Surfaces are demarcated primarily by a fine, single-pixel hairline border (`1px solid #E2E8F0`). On dark surfaces (sidebar and modal headers), borders shift to `1px solid rgba(255, 255, 255, 0.08)`.
- **Restrained Ambient Shadows:**
  - **Elevation Low (Cards, Row Hovers):** `0 1px 2px 0 rgba(15, 23, 42, 0.04)`.
  - **Elevation Medium (Dropdowns, Popovers):** `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
  - **Elevation High (Command Bar, Global Modals):** `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.
- **Command Overlays:** Modals and global search command palettes (CMD+K) utilize a backdrop overlay of `#0B132B` at 40% opacity with a subtle `backdrop-blur(4px)` to isolate active context without disorienting the engineer.

## Shapes

The design system maintains a disciplined, soft-cornered geometry (Level 1: `0.25rem` / `4px` base radius). 

- **Atomic Controls (4px / `0.25rem`):** Buttons, text inputs, segmented pills, table rows, and keycap badges use tight 4px radii to reinforce precision and modularity.
- **Containers & Panels (8px / `0.5rem`):** Cards, modal windows, flyout sheets, and data grids scale to an 8px (`rounded-lg`) corner radius.
- **Pill Identifiers:** Status badges, avatar frames, and milestone counts alone use circular/full radius (`9999px`) styling to contrast sharply against rectangular data tables.

## Components

### Buttons & Interactive Triggers
- **Primary:** Background `#1C2541`, text `#FFFFFF`, 1px border `#0B132B`. Hover shifts to `#0B132B` with crisp inset highlight. Focused state: 2px ring `#4F46E5` with 2px white offset.
- **Secondary / Ghost:** Background `#FFFFFF`, text `#334155`, border `1px solid #E2E8F0`. Hover shifts background to `#F8FAFC` and border to `#CBD5E1`.
- **Tertiary Accent (University Special Action):** Background `#D97706`, text `#FFFFFF`. Used strictly for "Submit Capstone for Defense", "Approve Project Proposal", or "Grade Milestone".
- **Compact Metrics:** Standard height is 32px for enterprise toolbar actions; 38px for hero form submissions.

### Status Pills & Badges
- Built using full pill radii (`rounded-full`), padded `2px 8px`, typography `label-sm` (11px, semi-bold).
- **Healthy:** Background `#ECFDF5`, text `#047857`, border `1px solid #A7F3D0`. Prepended with a solid 6px emerald dot.
- **At Risk:** Background `#FFFBEB`, text `#B45309`, border `1px solid #FDE68A`. Prepended with an amber pulse dot.
- **Blocked:** Background `#FEF2F2`, text `#B91C1C`, border `1px solid #FECACA`.
- **Submitted / In Review:** Background `#EEF2FF`, text `#4338CA`, border `1px solid #C7D2FE`.
- **Approved / Merged:** Background `#F8FAFC`, text `#0F172A`, border `1px solid #CBD5E1`.

### Data Grids & Tables
- **Header:** Height 36px, background `#F8FAFC`, bottom border `1px solid #E2E8F0`, typography `label-sm` in `#64748B`, uppercase with tabular alignment.
- **Row:** Height 40px (compact) or 48px (standard), background `#FFFFFF`, bordered bottom by `1px solid #F1F5F9`. Hover background shifts seamlessly to `#F8FAFC`.

### Form Inputs & Selectors
- **Base Input:** Background `#FFFFFF`, border `1px solid #CBD5E1`, border-radius 4px, height 36px, padding `0 12px`.
- **Focus State:** Border changes to `#4F46E5` with `box-shadow: 0 0 0 1px #4F46E5`.
- **Add-on Icons & Keycaps:** Monospaced keyboard shortcut badges (`kbd`) styled in `#F1F5F9` with `#64748B` labels at the trailing edge of inputs.

### Project & Repository Cards
- Constructed with `#FFFFFF` background, `1px solid #E2E8F0` perimeter, 8px corner radius.
- Card Header houses the project title (`headline-sm`), team avatar stack, and crest-aligned milestone badge.
- Card Footer integrates miniature git-commit metrics, branch icons, and dynamic milestone progress bars colored in `#4F46E5`.